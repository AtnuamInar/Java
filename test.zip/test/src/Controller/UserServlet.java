package Controller;

import domains.User;
import services.UserService;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class UserServlet extends javax.servlet.http.HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
        String pageRequest = request.getParameter("pageRequest");
        if (pageRequest.equalsIgnoreCase("login")) {
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            User user = new UserService().getUser(username, password);

            if (user != null) {
                request.setAttribute("msg", "Login Successful!!");
                RequestDispatcher rd = request.getRequestDispatcher("user/home.jsp");
                rd.forward(request, response);
            }else{
                request.setAttribute("msg","Invalid User or Password!!");
                RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
                rd.forward(request, response);
            }
        }
        if (pageRequest.equalsIgnoreCase("logout")) {
            request.setAttribute("msg","Logout Successful!!");
            RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
            rd.forward(request, response);
        }
        if (pageRequest.equalsIgnoreCase("list")) {
            redirectToList(request, response);
        }
        if (pageRequest.equalsIgnoreCase("userForm")) {
            RequestDispatcher rd = request.getRequestDispatcher("user/userForm.jsp");
            rd.forward(request, response);
        }
        if (pageRequest.equalsIgnoreCase("addUser")) {
            //get params from UI
            //insert into database
            //list page
            User user = new User();
            user.setName(request.getParameter("username"));
            user.setPassword(request.getParameter("password"));
            user.setEmail(request.getParameter("email"));
            user.setRole(request.getParameter("role"));

            new UserService().insert(user);


            redirectToList(request, response);

        }

        if (pageRequest.equalsIgnoreCase("deleteUser")) {
            //get id from UI
            //delete user from database
            //list page
            int id = Integer.parseInt(request.getParameter("id"));
            new UserService().delete(id);
            redirectToList(request, response);

        }
        if (pageRequest.equalsIgnoreCase("editUser")) {
            //get id
            int id = Integer.parseInt(request.getParameter("id"));
            User user = new UserService().getUser(id);
            request.setAttribute("user", user);
            RequestDispatcher rd = request.getRequestDispatcher("user/editUser.jsp");
            rd.forward(request, response);

        }
        if (pageRequest.equalsIgnoreCase("updateUser")) {
            User user = new User();
            user.setName(request.getParameter("username"));
            user.setPassword(request.getParameter("password"));
            user.setEmail(request.getParameter("email"));
            user.setRole(request.getParameter("role"));
            user.setId(Integer.parseInt(request.getParameter("id")));

            new UserService().update(user);


            redirectToList(request, response);

        }

    }

    private void redirectToList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<User> userList = new UserService().userList();
        request.setAttribute("users", userList);
        RequestDispatcher rd = request.getRequestDispatcher("user/list.jsp");
        rd.forward(request, response);
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
    doPost(request,response);
    }
}
