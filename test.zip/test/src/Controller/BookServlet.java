package Controller;

import domains.Book;
import domains.User;
import services.BookService;
import services.UserService;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "BookServlet")
public class BookServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pageRequest = request.getParameter("pageRequest");
        if (pageRequest.equalsIgnoreCase("list")) {
            redirectToList(request, response);
        }

        if (pageRequest.equalsIgnoreCase("logout")) {
            request.setAttribute("msg","Logout Successful!!");
            RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
            rd.forward(request, response);
        }

        if (pageRequest.equalsIgnoreCase("list")) {
            redirectToList(request, response);
        }

        if (pageRequest.equalsIgnoreCase("bookForm")) {
            RequestDispatcher rd = request.getRequestDispatcher("book/bookForm.jsp");
            rd.forward(request, response);
        }

        if (pageRequest.equalsIgnoreCase("addBook")) {
            //get params from UI
            //insert into database
            //list page
            Book book = new Book();
            book.setId(Integer.parseInt(request.getParameter("id")));
            book.setName(request.getParameter("name"));
            book.setAuthor(request.getParameter("author"));
            new BookService().insert(book);


            redirectToList(request, response);

        }

        if (pageRequest.equalsIgnoreCase("deleteBook")) {
            //get id from UI
            //delete user from database
            //list page
            int id = Integer.parseInt(request.getParameter("id"));
            new BookService().delete(id);
            redirectToList(request, response);

        }

        if (pageRequest.equalsIgnoreCase("editBook")) {
            //get id
            int id = Integer.parseInt(request.getParameter("id"));
            Book book = new BookService().getBook(id);
            request.setAttribute("book", book);
            RequestDispatcher rd = request.getRequestDispatcher("book/editBook.jsp");
            rd.forward(request, response);

        }

        if (pageRequest.equalsIgnoreCase("updateBook")) {
            Book book = new Book();
            book.setId(Integer.parseInt(request.getParameter("id")));
            book.setName(request.getParameter("name"));
            book.setAuthor(request.getParameter("author"));

            new BookService().update(book);


            redirectToList(request, response);

        }
    }

    private void redirectToList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Book> bookList = new BookService().bookList();
        request.setAttribute("books", bookList);
        RequestDispatcher rd = request.getRequestDispatcher("book/list.jsp");
        rd.forward(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
