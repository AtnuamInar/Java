package services;

import dbconnection.DatabaseConnection;
import domains.User;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserService {
    public void insert(User user) {

        String query = "insert into user " +
                "(name,password,email,role)" +
                " values(?,?,?,?)";

        try {
            PreparedStatement pstm = new DatabaseConnection().getPreparedStatement(query);
            pstm.setString(1, user.getName());
            pstm.setString(2, user.getPassword());
            pstm.setString(3, user.getEmail());
            pstm.setString(4, user.getRole());

             pstm.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void update(User user) {

        String query = "update user set name=?, password=?, email=?, role=? where id=?";

        try {
            PreparedStatement pstm = new DatabaseConnection().getPreparedStatement(query);
            pstm.setString(1, user.getName());
            pstm.setString(2, user.getPassword());
            pstm.setString(3, user.getEmail());
            pstm.setString(4, user.getRole());
            pstm.setInt(5, user.getId());

            pstm.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void delete(int id) {

        String query = "delete from user where id=?";

        try {
            PreparedStatement pstm = new DatabaseConnection().getPreparedStatement(query);
            pstm.setInt(1, id);

            pstm.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public List<User> userList() {
        List<User> userList = new ArrayList<>();

        String query = "select * from user";
        try {
            PreparedStatement pstm = new DatabaseConnection().getPreparedStatement(query);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                User user = new User();
                user = new User();
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("name"));
                user.setPassword(rs.getString("password"));
                user.setEmail(rs.getString("email"));
                user.setRole(rs.getString("role"));
                userList.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return userList;
    }

    public User getUser(String username, String password) {
        User user = null;
        String query = "select * from user where name=? and password=?";
        try {
            PreparedStatement pstm = new DatabaseConnection().getPreparedStatement(query);
            pstm.setString(1, username);
            pstm.setString(2,password);

            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                user = new User();
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("name"));
                user.setPassword(rs.getString("password"));
                user.setEmail(rs.getString("email"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }
    public User getUser(int id) {
        User user = null;
        String query = "select * from user where id=?";
        try {
            PreparedStatement pstm = new DatabaseConnection().getPreparedStatement(query);
            pstm.setInt(1, id);

            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                user = new User();
                user.setId(rs.getInt("id"));
                user.setName(rs.getString("name"));
                user.setPassword(rs.getString("password"));
                user.setEmail(rs.getString("email"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return user;
    }



}
