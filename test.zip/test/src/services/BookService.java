package services;

import dbconnection.DatabaseConnection;
import domains.Book;
import domains.User;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BookService {
    public void insert(Book book) {

        String query = "insert into book " +
                "(id, name, author)" +
                " values(?,?,?)";

        try {
            PreparedStatement pstm = new DatabaseConnection().getPreparedStatement(query);
            pstm.setInt(1, book.getId());
            pstm.setString(2, book.getName());
            pstm.setString(3, book.getAuthor());

            pstm.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void update(Book book) {

        String query = "update book set name=?, author=? where id=?";

        try {
            PreparedStatement pstm = new DatabaseConnection().getPreparedStatement(query);
            pstm.setString(2, book.getName());
            pstm.setString(3, book.getAuthor());
            pstm.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void delete(int id) {

        String query = "delete from book where id=?";

        try {
            PreparedStatement pstm = new DatabaseConnection().getPreparedStatement(query);
            pstm.setInt(1, id);

            pstm.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public List<Book> bookList() {
        List<Book> bookList = new ArrayList<>();

        String query = "select * from book";
        try {
            PreparedStatement pstm = new DatabaseConnection().getPreparedStatement(query);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                Book book = new Book();
                book.setId(Integer.parseInt(rs.getString("id")));
                book.setName(rs.getString("name"));
                book.setAuthor(rs.getString("author"));
                bookList.add(book);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bookList;
    }

//    public Book getBook() {
//        Book book = null;
//        String query = "select * from book where name=? and password=?";
//        try {
//            PreparedStatement pstm = new DatabaseConnection().getPreparedStatement(query);
//            pstm.setString(1, username);
//            pstm.setString(2,password);
//
//            ResultSet rs = pstm.executeQuery();
//            while (rs.next()) {
//                user = new User();
//                user.setId(rs.getInt("id"));
//                user.setName(rs.getString("name"));
//                user.setPassword(rs.getString("password"));
//                user.setEmail(rs.getString("email"));
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return user;
//    }
    public Book getBook(int id) {
        Book book = null;
        String query = "select * from book where id=?";
        try {
            PreparedStatement pstm = new DatabaseConnection().getPreparedStatement(query);
            pstm.setInt(1, id);

            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                book.setId(Integer.parseInt(rs.getString("id")));
                book.setName(rs.getString("name"));
                book.setAuthor(rs.getString("author"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return book;
    }
}
