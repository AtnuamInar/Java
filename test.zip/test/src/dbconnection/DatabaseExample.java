package dbconnection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseExample {


    public void insert(){
        try {
            String query = "insert into user (name,password,email,role) " +
                    "values(?,?,?,?)";

            PreparedStatement pstm = new DatabaseConnection().getPreparedStatement(query);
            pstm.setString(1, "XYZ");
            pstm.setString(2, "PAR");
            pstm.setString(3, "a@aa.com");
            pstm.setString(4, "ADMIN");

            pstm.execute();


            System.out.println("data inserted!!!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void delete(){
        String query = "delete user from user where id=?";
        try {
            PreparedStatement pstm = new DatabaseConnection().getPreparedStatement(query);
            pstm.setInt(1, 1);
            pstm.execute();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args) {
        DatabaseExample ex = new DatabaseExample();
       /* ex.insert();
        ex.insert();
        ex.insert();
        ex.insert();
        ex.insert();*/
        //ex.delete();
        ex.select();

    }

    public void select(){
        String query = "select * from user";
        try {
            DatabaseConnection db = new DatabaseConnection();
            PreparedStatement pstm = db.getPreparedStatement(query);

            ResultSet rs = pstm.executeQuery();

            while (rs.next()) {
                System.out.println("========================");
                System.out.println("Name-->"+rs.getString("name"));
                System.out.println("Password-->"+rs.getString("password"));
                System.out.println("Email-->"+rs.getString("email"));
                System.out.println("Role-->"+rs.getString("role"));
                System.out.println("========================");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
